---
id: "COST01-BP09"
title: "Quantify business value from cost optimization"
framework: "WAF"
domain: "Cost Optimization"
capability: "How do you implement cloud financial management?"
risk_level: "Medium"
---

# COST01-BP09 Quantify business value from cost optimization

## Implementation Guidance
 Quantifying the business value means measuring the benefits that businesses gain from the actions and decisions they take. Business value can be tangible (like reduced expenses or increased profits) or intangible (like improved brand reputation or increased customer satisfaction).

 To quantify business value from cost optimization means determining how much value or benefit you’re getting from your efforts to spend more efficiently. For example, if a company spends \$1100,000 to deploy a workload on AWS and later optimizes it, the new cost becomes only \$180,000 without sacrificing the quality or output. In this scenario, the quantified business value from cost optimization would be a savings of \$120,000. But beyond just savings, the business might also quantify value in terms of faster delivery times, improved customer satisfaction, or other metrics that result from the cost optimization efforts. Stakeholders need to make decisions about the potential value of cost optimization, the cost of optimizing the workload, and return value.

 In addition to reporting savings from cost optimization, it is recommended that you quantify the additional value delivered. Cost optimization benefits are typically quantified in terms of lower costs per business outcome. For example, you can quantify Amazon Elastic Compute Cloud(Amazon EC2) cost savings when you purchase Savings Plans, which reduce cost and maintain workload output levels. You can quantify cost reductions in AWS spending when idle Amazon EC2 instances are removed, or unattached Amazon Elastic Block Store (Amazon EBS) volumes are deleted.

 The benefits from cost optimization, however, go above and beyond cost reduction or avoidance. Consider capturing additional data to measure efficiency improvements and business value.

## Implementation Steps
- **Evaluate business benefits:** This is the process of analyzing and adjusting AWS Cloud cost in ways that maximize the benefit received from each dollar spent. Instead of focusing on cost reduction without business value, consider business benefits and return on investments for cost optimization, which may bring more value out of the money you spend. It's about spending wisely and making investments and expenditures in areas that yield the best return.
- **Analyze forecasting AWS costs:** Forecasting helps finance stakeholders set expectations with other internal and external organization stakeholders, and can improve your organization’s financial predictability. [AWS Cost Explorer](https://aws.amazon.com/aws-cost-management/aws-cost-explorer/) can be used to perform forecasting for your cost and usage.

## Resources
### Related Documents
- [AWS Cloud Economics ](https://aws.amazon.com/economics/)
- [AWS Blog](https://aws.amazon.com/blogs/)
- [AWS Cost Management](https://aws.amazon.com/blogs/aws-cost-management/)
- [AWS News Blog](https://aws.amazon.com/blogs/aws/)
- [Well-Architected Reliability Pillar whitepaper](https://docs.aws.amazon.com/wellarchitected/latest/reliability-pillar/welcome.html)
- [AWS Cost Explorer](https://aws.amazon.com/aws-cost-management/aws-cost-explorer/)
### Related Videos
- [ Unlock Business Value with Windows on AWS](https://aws.amazon.com/windows/tco/)
### Related Examples
- [ Measuring and Maximizing the Business Value of Customer 360 ](https://pages.awscloud.com/measuring-and-maximizing-the-business-value-of-customer-360-062022.html)
- [ The Business Value of Adopting Amazon Web Services Managed Databases ](https://pages.awscloud.com/rs/112-TZM-766/images/The Business Value of Adopting Amazon Web Services Managed Databases.pdf)
- [ The Business Value of Amazon Web Services for Independent Software Vendors ](https://pages.awscloud.com/rs/112-TZM-766/images/The Business Value of Amazon Web Services %28AWS%29 for Independent Software Vendors %28ISVs%29.pdf)
- [ Business Value of Cloud Modernization ](https://pages.awscloud.com/aws-cfm-known-business-value-of-cloud-modernization-2022.html)
- [ The Business Value of Migration to Amazon Web Services ](https://pages.awscloud.com/global-in-gc-500-business-value-of-migration-whitepaper-learn.html)
