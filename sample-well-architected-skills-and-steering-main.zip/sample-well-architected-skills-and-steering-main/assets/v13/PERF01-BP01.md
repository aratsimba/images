---
id: "PERF01-BP01"
title: "Learn about and understand available cloud services and features"
framework: "WAF"
domain: "Performance Efficiency"
capability: "How do you select appropriate cloud resources and architecture for your workload?"
risk_level: "High"
---

# PERF01-BP01 Learn about and understand available cloud services and features

## Anti-Patterns
- You use the cloud as a collocated data center.
- You do not modernize your application after migration to the cloud.
- You only use one storage type for all things that need to be persisted.
- You use instance types that are closest matched to your current standards, but are larger where needed.
- You deploy and manage technologies that are available as managed services.

## Implementation Guidance
 AWS continually releases new services and features that can improve performance and reduce the cost of cloud workloads. Staying up-to-date with these new services and features is crucial for maintaining performance efficacy in the cloud. Modernizing your workload architecture also helps you accelerate productivity, drive innovation, and unlock more growth opportunities.

## Implementation Steps
- Inventory your workload software and architecture for related services. Decide which category of products to learn more about.
- Explore AWS offerings to identify and learn about the relevant services and configuration options that can help you improve performance and reduce cost and operational complexity.
  - [ Amazon Web Services Cloud ](https://docs.aws.amazon.com/whitepapers/latest/aws-overview/amazon-web-services-cloud-platform.html)
  - [AWS Academy ](https://aws.amazon.com/training/awsacademy/)
  - [What’s New with AWS?](https://aws.amazon.com/new/)
  - [AWS Blog](https://aws.amazon.com/blogs/)
  - [AWS Skill Builder](https://skillbuilder.aws/)
  - [AWS Events and Webinars](https://aws.amazon.com/events/)
  - [AWS Training and Certifications](https://www.aws.training/)
  - [AWS Youtube Channel](https://www.youtube.com/channel/UCd6MoB9NC6uYN2grvUNT-Zg)
  - [AWS Workshops](https://workshops.aws/)
  - [AWS Communities](https://aws.amazon.com/events/asean/community-and-events/)
- Use [Amazon Q](https://aws.amazon.com/q/) to get relevant information and advice about services.
- Use sandbox (non-production) environments to learn and experiment with new services without incurring extra cost.
- Continually learn about new cloud services and features.

## Resources
### Related Documents
- [ Overview of Amazon Web Services ](https://docs.aws.amazon.com/whitepapers/latest/aws-overview/introduction.html)
- [ Amazon EC2 features ](https://aws.amazon.com/ec2/features/)
- [ Learn step-by-step with an AWS Partner Learning Plan ](https://aws.amazon.com/partners/training/aws-partner-learning-plans/)
- [AWS Training and Certification ](https://aws.amazon.com/training/)
- [ My learning path to become an AWS solutions architect ](https://aws.amazon.com/blogs/training-and-certification/my-learning-path-to-become-an-aws-solutions-architect/)
- [AWS Architecture Center](https://aws.amazon.com/architecture/)
- [AWS Partner Network](https://aws.amazon.com/partners/)
- [AWS Solutions Library](https://aws.amazon.com/solutions/)
- [AWS Knowledge Center](https://aws.amazon.com/premiumsupport/knowledge-center/)
- [Build modern applications on AWS](https://aws.amazon.com/modern-apps/)
### Related Videos
- [AWS re:Invent 2023 - What’s new with Amazon EC2 ](https://www.youtube.com/watch?v=mjHw_wgJJ5g)
- [AWS re:Invent 2022 - Reduce your operational and infrastructure costs with Amazon ECS ](https://www.youtube.com/watch?v=vwf0rcdXdVE)
- [AWS re:Invent 2023 - Build with the efficiency, agility & innovation of the cloud with AWS](https://www.youtube.com/watch?v=AMrXMfYYVXs)
- [AWS re:Invent 2022 - Deploy ML models for inference at high performance and low cost ](https://www.youtube.com/watch?v=4FqHt5bmS2o)
- [This is my Architecture](https://aws.amazon.com/architecture/this-is-my-architecture/)
### Related Examples
- [AWS Samples](https://github.com/aws-samples)
- [AWS SDK Examples](https://github.com/awsdocs/aws-doc-sdk-examples)
